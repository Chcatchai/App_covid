package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase



class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        auth = Firebase.auth

        val BtLogin = findViewById<Button>(R.id.BtLogin)
        val email = findViewById<TextView>(R.id.editTextEmail)
        val password = findViewById<TextView>(R.id.editTextPassword)
        val tvResponse = findViewById<TextView>(R.id.tvResponse)
        val tvRegister = findViewById<TextView>(R.id.tvRegister)

        BtLogin.setOnClickListener {
            val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
            if (email.text.toString().isNullOrEmpty() || password.text.toString()
                            .isNullOrEmpty())
                tvResponse.text = "Email Address or Password is not provided"

            /*else if(email.text.toString().isNotEmpty() || password.text.toString().isNotEmpty())
                auth.signInWithEmailAndPassword(email.text.toString(), password.text.toString())
                        .addOnCompleteListener(this) { task ->
                            if (task.isSuccessful) {
                                // Sign in success, update UI with the signed-in user's information
                                Log.d(TAG, "signInWithEmail:success")
                                val user = auth.currentUser
                                updateUI(user)
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w("signInWithEmail:failure", task.exception)
                                Toast.makeText(baseContext, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show()
                                updateUI(null)
                            }}*/
            else {
                auth.createUserWithEmailAndPassword(
                        email.text.toString(),
                        password.text.toString())
                        .addOnCompleteListener(this) { task ->
                            if (task.isSuccessful) {
                                tvResponse.text =
                                        "Sign Up successfull. Email and Password created"
                                val user = auth.currentUser
                                updateUI(user)
                            } else {
                                tvResponse.text = "Sign Up Failed"
                                updateUI(null)
                            }

              /*  auth.signInWithEmailAndPassword(email.text.toString(), password.text.toString())
                        .addOnCompleteListener(this) { task ->
                            if (task.isSuccessful) {
                                // Sign in success, update UI with the signed-in user's information
                                //Log.d(TAG, "signInWithEmail:success")
                                val user = auth.currentUser
                                updateUI(user)
                            } else {
                                // If sign in fails, display a message to the user.
                                //Log.w(TAG, "signInWithEmail:failure", task.exception)
                                Toast.makeText(baseContext, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show()
                                updateUI(null)

                            }*/
                        }

            }
        }
        //Register
        tvRegister.setOnClickListener {
            val i = Intent(this,page2::class.java)
            startActivity(i)
        }


    }
    private fun updateUI(currentUser: FirebaseUser?) {

    }
    public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        updateUI(currentUser)
    }

}