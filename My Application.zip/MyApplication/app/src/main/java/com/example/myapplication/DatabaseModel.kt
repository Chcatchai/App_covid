package com.example.myapplication

class DatabaseModel (var Name:String ,var email:String){
}