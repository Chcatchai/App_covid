package com.example.myapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.android.synthetic.main.activity_get_firestore_data.*

class GetFirestoreData : AppCompatActivity() {
    private lateinit var database: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_get_firestore_data)
        database = FirebaseFirestore.getInstance()

    }
    private fun getData()
    {
        database.collection("Users").get().addOnCompleteListener(object :OnCompleteListener<QuerySnapshot>
        {
            override fun onComplete(p0: Task<QuerySnapshot>) {
                var list = ArrayList<DatabaseModel>()
                if (p0.isSuccessful){
                    for (data in p0.result!!)
                    {
                        list.add(DatabaseModel(data.get("na me") as String,data.get("email") as String))
                    }
                    var adapter=DataAdapter(list)
                    recyclerview.adapter=adapter
                }

            }

        })

    }
}