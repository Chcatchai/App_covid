package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_page2.*


class page2 : AppCompatActivity() {
    private lateinit var database: FirebaseFirestore
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page2)
        database = FirebaseFirestore.getInstance()

        val Login = findViewById<TextView>(R.id.tvLogin)
        val Confirm = findViewById<Button>(R.id.buttonConfirm)

        val email = findViewById<TextView>(R.id.editTextEmail)
        val password = findViewById<TextView>(R.id.editTextPassword)
        val Name = findViewById<TextView>(R.id.editTextName)


        //Confirm
        Confirm.setOnClickListener {
            sendData()
        }
        Login.setOnClickListener {
            startActivity(Intent(applicationContext,GetFirestoreData::class.java))
        }
    }

    private fun sendData() {
        var email = editTextEmail.text.toString().trim()
        var Name = editTextName.text.toString().trim()

        if (email.isNotEmpty() || Name.isNotEmpty()) {

            var mode = DatabaseModel(Name, email)
            database.collection("Users").add(mode).addOnSuccessListener(object : OnSuccessListener<DocumentReference> {
                override fun onSuccess(p0: DocumentReference?) {
                    editTextName.setText("")
                    editTextEmail.setText("")
                }

            }).addOnFailureListener(object :OnFailureListener{
                override fun onFailure(p0: Exception) {
                    Toast.makeText(applicationContext,"Failed",Toast.LENGTH_LONG).show()
                }
            })

        }
    }
}