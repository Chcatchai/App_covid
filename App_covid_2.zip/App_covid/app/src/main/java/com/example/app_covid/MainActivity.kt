package com.example.app_covid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_main.*



class MainActivity : AppCompatActivity() {

    private lateinit var edUser:EditText
    private lateinit var btAdd: Button
    private val connectDB = Firebase.firestore
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edUser =findViewById(R.id.edUser)

        btAdd.setOnClickListener(this)
    }

    override fun onClick(v:View) {
        saveData()
    }

    private fun saveData() {
        val user:String = edUser.text.toString()

        if (user.isEmpty()){
            edUser.error = "Empty!"
            return
        }

    }
    /*
    )

    btMain.setOnClickListener{
        connectDB.collection("Locations").document("La")
        .set(city) }
       // .addOnSuccessListener { Log.d(TAG, "DocumentSnapshot successfully written!") }
       // .addOnFailureListener { e -> Log.w(TAG, "Error writing document", e) }

    }*/


    /* fun btaAdd(v:View) {
        val edUser:String = edUser.text.toString()

         val city = hashMapOf(
             "name" to edUser,
             "state" to "CA",
             "country" to "USA"
         )
            connectDB.collection("Locations").document("La")
                .set(city)*/
    }




    /*    btMain.setOnClickListener {
         val userName = userId.text;
         val passWord = password.text;
         val databaseApp = connectDB.collection("Databast_app").document("userName")


         if (userName.trim() == databaseApp|| passWord.trim() == databaseApp){
             Toast.makeText(this,"Login Complete",Toast.LENGTH_LONG).show()
         }
         /*else if (userName.trim() != databaseApp|| passWord.trim() != databaseApp){
             Toast.makeText(this,"Username or Passsword error",Toast.LENGTH_LONG).show()
         }*/
         else {
             Toast.makeText(this,"Input Username or Password",Toast.LENGTH_LONG).show()
         }
     }*/


////////////////////////////////////////////
    /*data class User(
        val Name: String? = null,
        val Email: String? = null,
    )
    val user = User("Ken", "ken")


    Database.collection("Users").document("1").set(user)*/

    // Database.collection("Users").document("1").set(user)
    /*  val user = hashMapOf(
          "ID" to "${UserId.text}")

      BtLogin.setOnClickListener {
          Database.collection("Users").document("1").set(user)
      }
*/



/*
class MyApplication : MultiDexApplication() {

    public fun setup() {
        // [START get_firestore_instance]
        val db = Firebase.firestore
        // [END get_firestore_instance]
        // [START set_firestore_settings]
        val settings = firestoreSettings {
            isPersistenceEnabled = true
        }
        db.firestoreSettings = settings
// [END set_firestore_settings]
        val docRef = db.collection("Databast_app").document("User1")
        docRef.get()
            .addOnSuccessListener { document ->
                if (document != null) {
                    Log.d(TAG, "DocumentSnapshot data: ${document.data}")
                } else {
                    Log.d(TAG, "No such document")
                }
            }
            .addOnFailureListener { exception ->
                Log.d(TAG, "get failed with ", exception)
            }
    // [END get_multiple]
}

}
*/